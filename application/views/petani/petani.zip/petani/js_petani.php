<script src="<?php echo base_url();?>assets/lib/jquery/jquery.js"></script>
    <script src="<?php echo base_url();?>assets/lib/popper.js/popper.js"></script>
    <script src="<?php echo base_url();?>assets/lib/bootstrap/bootstrap.js"></script>
    <script src="<?php echo base_url();?>assets/lib/jquery-ui/jquery-ui.js"></script>
    <script src="<?php echo base_url();?>assets/lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
    <script src="<?php echo base_url();?>assets/lib/jquery.sparkline.bower/jquery.sparkline.min.js"></script>
    <script src="<?php echo base_url();?>assets/lib/d3/d3.js"></script>
    <script src="<?php echo base_url();?>assets/lib/rickshaw/rickshaw.min.js"></script>
    <script src="<?php echo base_url();?>assets/lib/chart.js/Chart.js"></script>
    <script src="<?php echo base_url();?>assets/lib/Flot/jquery.flot.js"></script>
    <script src="<?php echo base_url();?>assets/lib/Flot/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url();?>assets/lib/Flot/jquery.flot.resize.js"></script>
    <script src="<?php echo base_url();?>assets/lib/flot-spline/jquery.flot.spline.js"></script>

    <script src="<?php echo base_url();?>assets/js/starlight.js"></script>
    <script src="<?php echo base_url();?>assets/js/ResizeSensor.js"></script>
    <script src="<?php echo base_url();?>assets/js/dashboard.js"></script>

    <script src="<?php echo base_url();?>assets/lib/datatables/jquery.dataTables.js"></script>


    <script src="<?php echo base_url();?>assets/lib/highlightjs/highlight.pack.js"></script>

    <script src="<?php echo base_url();?>assets/lib/datatables-responsive/dataTables.responsive.js"></script>
    <script src="<?php echo base_url();?>assets/lib/select2/js/select2.min.js"></script>
<!-- icon -->
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>